export const Scripts: ModdedBattleScriptsData = {
	inherit: 'gen8',
	gen: 7,
};
