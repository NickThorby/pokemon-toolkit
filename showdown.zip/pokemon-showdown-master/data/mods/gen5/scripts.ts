export const Scripts: ModdedBattleScriptsData = {
	inherit: 'gen6',
	gen: 5,
};
