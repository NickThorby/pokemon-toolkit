export const FormatsData: {[k: string]: ModdedSpeciesFormatsData} = {
	pikachupartner: {
		isNonstandard: "Future",
		tier: "Illegal",
	},
	marowakalolatotem: {
		isNonstandard: "Future",
		tier: "Illegal",
	},
	ribombeetotem: {
		isNonstandard: "Future",
		tier: "Illegal",
	},
	rockruffdusk: {
		isNonstandard: "Future",
		tier: "Illegal",
	},
	lycanrocdusk: {
		isNonstandard: "Future",
		tier: "Illegal",
	},
	araquanidtotem: {
		isNonstandard: "Future",
		tier: "Illegal",
	},
	necrozmaduskmane: {
		isNonstandard: "Future",
		tier: "Illegal",
	},
	necrozmadawnwings: {
		isNonstandard: "Future",
		tier: "Illegal",
	},
	necrozmaultra: {
		isNonstandard: "Future",
		tier: "Illegal",
	},
	poipole: {
		isNonstandard: "Future",
		tier: "Illegal",
	},
	naganadel: {
		isNonstandard: "Future",
		tier: "Illegal",
	},
	stakataka: {
		isNonstandard: "Future",
		tier: "Illegal",
	},
	blacephalon: {
		isNonstandard: "Future",
		tier: "Illegal",
	},
	zeraora: {
		isNonstandard: "Future",
		tier: "Illegal",
	},
};
